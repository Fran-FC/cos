{ printf "practica\ncos\n1\n9\n1\nyes\n\n\033\0334"; } | telnet 158.42.181.26
